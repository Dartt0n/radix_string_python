# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['radix_string']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'radix-string',
    'version': '0.1.1',
    'description': 'Function for python to convert integer to any base',
    'long_description': None,
    'author': 'Anton Kudryavtsev',
    'author_email': 'antonkudryavtsevdoem@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
